# Poseidon Creature Asset Library

Last updated: **2026-09-07**

This is the human review ledger for Poseidon creature artwork. The machine-readable source of truth for the current ChatGPT batch is [`assets/source/creatures/catalog.json`](../assets/source/creatures/catalog.json). Runtime assets remain under `assets/creatures/` and are produced through the canonical asset pipeline.

## Current state

- **30** unique square source candidates in style family `poseidon-sunlit-square-v1`.
- **17 keep**, **6 provisional**, **7 remake**.
- **23** are usable as visual candidates today (`keep` + `provisional`).
- A repo-ready binary bundle contains about **3.2 MiB** of normalized 1024×1024 high-quality WebP masters, matching the current maximum hero canvas. **Binary import is still pending** because the chat GitHub connector cannot upload local binary files.
- The later wide photorealistic eagle-ray/hawksbill experiments and the infographic collage are intentionally excluded from this canonical source library to avoid style drift and duplicate species.

## Architecture

```text
assets/
  source/
    creatures/
      catalog.json
      README.md
      <creature-or-provisional-id>/
        candidate-v1.webp
  creatures/
    <stable-creature-id>/
      manifest.json
      thumb.webp
      gallery.webp
      hero.webp
```

The separation is deliberate. `assets/source` is editorial input; `assets/creatures` is validated runtime output. Components should consume only canonical manifests/variants, never source candidates.

## Review dimensions

Each candidate is reviewed for: **species identity**, **anatomy**, **markings/colour**, **regional plausibility**, **composition/crop**, **Poseidon style consistency**, **generation artifacts**, and **pipeline readiness**. A high aesthetic score does not override incorrect species morphology.

## Inventory

| Species | Content ID | Score | State | Identity | Notes |
| --- | --- | ---: | --- | --- | --- |
| Queen angelfish | `queen-angelfish` | 8.5/10 | **keep** | high | Strong silhouette and palette; crown/markings slightly stylized but clearly recognizable. |
| Hawksbill sea turtle | `hawksbill-sea-turtle` | 9.0/10 | **keep** | high | One of the strongest assets; good hooked beak, shell character and overall proportions. |
| Spotted eagle ray | `spotted-eagle-ray` | 6.5/10 | **remake** | medium | Attractive, but head/snout and ray morphology drift toward a generic stylized ray; remake before canonical use. |
| Nurse shark | `nurse-shark` | 7.7/10 | **provisional** | medium | Recognizable from barbels and body form; caudal/dorsal proportions deserve biological QA. |
| Green moray | `green-moray` | 8.3/10 | **keep** | high | Strong recognizable form, color and mouth/head shape. |
| Great barracuda | `great-barracuda` | 8.4/10 | **keep** | high | Very recognizable; teeth are slightly exaggerated but the asset reads correctly. |
| Stoplight parrotfish | `stoplight-parrotfish` | 7.6/10 | **provisional** | medium | Good beak and body; coloration is more saturated/stylized than field-realistic. |
| Caribbean reef squid | `caribbean-reef-squid` | 7.4/10 | **provisional** | medium | Attractive and recognizably squid; large eyes and three-animal composition make it less ideal as an identification card. |
| Caribbean spiny lobster | `caribbean-spiny-lobster` | 9.0/10 | **keep** | high | Excellent antennae, armored body and coloration; immediately readable. |
| Caribbean reef octopus | `caribbean-reef-octopus` | 7.1/10 | **provisional** | medium | Visually excellent, but eye size and some arm/sucker anatomy are stylized; needs biological QA. |
| French angelfish | `french-angelfish` | 9.0/10 | **keep** | high | Very strong species-specific coloration and silhouette. |
| Spotted trunkfish | `spotted-trunkfish` | 3.0/10 | **remake** | low | Current candidate reads as a yellow Indo-Pacific boxfish rather than the intended Caribbean spotted trunkfish. |
| Queen triggerfish | `—` | 8.6/10 | **keep** | high | Strong tail, body and facial coloration; not yet represented in the starter content pack. |
| Nassau grouper | `nassau-grouper` | 8.2/10 | **keep** | high | Broad bars, grouper form and head pattern work well. |
| Blue tang | `blue-tang` | 4.0/10 | **remake** | low | Yellow-tail morphology makes this unreliable for Atlantic blue tang identification. |
| Southern stingray | `southern-stingray` | 8.2/10 | **keep** | high | Convincing silhouette and dorsal view; strong library candidate. |
| Trumpetfish | `trumpetfish` | 7.2/10 | **provisional** | medium | Recognizable elongated snout/body; fin configuration and proportions need reference checking. |
| Longsnout seahorse | `longsnout-seahorse` | 6.8/10 | **provisional** | medium | Beautiful but somewhat generic and over-spined; species-specific form could be stronger. |
| Yellowtail snapper | `yellowtail-snapper` | 9.0/10 | **keep** | high | Excellent profile, yellow stripe/tail and silver-blue body. |
| Porcupinefish | `porcupinefish` | 8.0/10 | **keep** | medium | Strong Diodon-type asset; use only with the porcupinefish label, not a generic puffer label. |
| Longspine sea urchin | `—` | 9.2/10 | **keep** | high | Excellent, simple and highly recognizable; not yet represented in starter content. |
| Banded coral shrimp | `—` | 8.8/10 | **keep** | high | Strong red/white banding, antennae and claw profile; not yet represented in starter content. |
| Schoolmaster snapper | `schoolmaster-snapper` | 8.7/10 | **keep** | high | Good yellow fins/stripes and snapper silhouette. |
| Spanish hogfish | `spanish-hogfish` | 2.5/10 | **remake** | low | Clearly wrong pattern/coloration for the intended species; do not promote. |
| Caribbean cushion sea star | `—` | 4.0/10 | **remake** | low | Current candidate is a thin-armed classic sea-star shape rather than a heavy cushion-like form. |
| Sergeant major | `sergeant-major` | 8.6/10 | **keep** | high | Strong five-bar appearance and recognizable Caribbean reef-fish form. |
| Porkfish | `porkfish` | 4.5/10 | **remake** | low | General grunt-like form is attractive, but markings are not reliable for porkfish identification. |
| Queen conch | `—` | 5.8/10 | **remake** | medium | Shell is attractive but exposed animal anatomy and midwater presentation are unreliable; remake. |
| Juvenile spotted drum | `—` | 8.1/10 | **keep** | high | Strong juvenile black/white profile with trailing fins; appropriately distinctive; not yet in starter content. |
| Green sea turtle | `green-sea-turtle` | 8.6/10 | **keep** | high | Good rounded head and smoother shell distinguish it from the hawksbill. |

## Remake queue

- **Spotted eagle ray** — Attractive, but head/snout and ray morphology drift toward a generic stylized ray; remake before canonical use.
- **Spotted trunkfish** — Current candidate reads as a yellow Indo-Pacific boxfish rather than the intended Caribbean spotted trunkfish.
- **Blue tang** — Yellow-tail morphology makes this unreliable for Atlantic blue tang identification.
- **Spanish hogfish** — Clearly wrong pattern/coloration for the intended species; do not promote.
- **Caribbean cushion sea star** — Current candidate is a thin-armed classic sea-star shape rather than a heavy cushion-like form.
- **Porkfish** — General grunt-like form is attractive, but markings are not reliable for porkfish identification.
- **Queen conch** — Shell is attractive but exposed animal anatomy and midwater presentation are unreliable; remake.

## Provisional QA queue

- **Nurse shark** — Recognizable from barbels and body form; caudal/dorsal proportions deserve biological QA.
- **Stoplight parrotfish** — Good beak and body; coloration is more saturated/stylized than field-realistic.
- **Caribbean reef squid** — Attractive and recognizably squid; large eyes and three-animal composition make it less ideal as an identification card.
- **Caribbean reef octopus** — Visually excellent, but eye size and some arm/sucker anatomy are stylized; needs biological QA.
- **Trumpetfish** — Recognizable elongated snout/body; fin configuration and proportions need reference checking.
- **Longsnout seahorse** — Beautiful but somewhat generic and over-spined; species-specific form could be stronger.

## Starter-pack alignment

The source library is allowed to run ahead of the 50-creature content pack, but runtime promotion should use a stable content creature ID. Candidates currently outside the starter pack are tracked with a provisional ID and must not silently create new taxonomy/content records.

- `queen-triggerfish` — Queen triggerfish
- `longspine-sea-urchin` — Longspine sea urchin
- `banded-coral-shrimp` — Banded coral shrimp
- `caribbean-cushion-sea-star` — Caribbean cushion sea star
- `queen-conch` — Queen conch
- `juvenile-spotted-drum` — Juvenile spotted drum

## Promotion workflow

1. Generate or replace one source candidate.
2. Record it in `catalog.json` with provenance and review state.
3. Biological/style QA; `remake` candidates stop here.
4. Map to an existing stable content ID (or land content work separately).
5. Promote with the canonical asset pipeline once the source treatment is supported.
6. Run asset validation.
7. Let the web app consume only generated `thumb` / `gallery` / `hero` variants through manifests.

## Stack and UI boundary

The active application integration already uses **React + Vite + TypeScript + Tailwind v4**, with **Lucide React** as the curated icon library. That is the right place for components and iconography. The asset library itself stays framework-neutral so artwork can be validated, replaced and reused without importing React or UI concerns.

## Next production backlog

- Remake the seven `remake` candidates before canonical promotion.
- Perform biological QA on the six `provisional` candidates.
- Extend the pipeline deliberately if Poseidon keeps the opaque underwater-scene art direction; do not weaken alpha validation globally without a source-mode contract.
- Continue coverage toward the full 50-creature Mexican Caribbean starter pack, prioritizing locally distinctive/common species and the splendid toadfish.
- Keep the existing generated/fallback runtime system until replacements pass QA; never trade correct fallback behavior for attractive but wrong art.


# Poseidon ChatGPT creature source-art import

Target branch scaffold: `asset-library-chatgpt-2026-09-07`.

Copy the `assets/source/creatures/<id>/candidate-v1.webp` files from this bundle into the same paths in the repository. Do not place these candidates under `assets/creatures/`; that directory is reserved for canonical generated runtime variants/manifests.

After copying:

1. Verify every path listed in `assets/source/creatures/catalog.json` exists.
2. Verify every candidate is 1024×1024 WebP and opens successfully.
3. Do not promote `status: remake` assets into runtime art.
4. `status: provisional` requires biological QA before promotion.
5. Existing runtime art from PR #10 remains authoritative until a replacement passes review and the canonical pipeline.
6. Do not weaken the existing transparent-source validation globally. If opaque scene art becomes canonical, implement a distinct source mode with explicit validation and tests.

The bundle contains 30 candidate masters plus the source catalog and human review ledger.

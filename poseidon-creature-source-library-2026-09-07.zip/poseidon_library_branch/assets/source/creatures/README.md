# Creature source-art library

This directory contains **candidate/source masters**, not runtime artwork.

- `assets/source/creatures/<id>/candidate-vN.webp` — immutable reviewed source candidates.
- `assets/source/creatures/catalog.json` — machine-readable editorial inventory and QA state.
- `assets/creatures/<id>/` — canonical generated runtime variants/manifests produced by the existing asset pipeline.

Application code must never import directly from `assets/source/`. A candidate becomes runtime art only after biological/style review and promotion through the canonical pipeline.

## Why source art is separate

The current pipeline validates every top-level directory under `assets/creatures` as canonical output. Keeping source candidates elsewhere avoids broken manifests, duplicate IDs and accidental use of unapproved art. It also lets us retain candidates that are explicitly marked `provisional` or `remake`.

## Source-master policy

The first library batch was generated interactively in ChatGPT on 2026-09-07. The original 1254×1254 PNG outputs were normalized into a repo-ready 1024×1024 high-quality WebP bundle (`quality=84`). This matches the current maximum hero canvas while avoiding roughly 60 MiB of PNG repository bloat; the 30 candidate masters total about 3.2 MiB. No compositional edit was applied. Binary import is pending because the chat GitHub connector cannot upload local binary files.

The current images are opaque square underwater scenes. `tools/creature_assets` currently expects transparent approved source art, so these candidates must not be forced through it until the pipeline is deliberately extended to support opaque scene masters or the art is converted to the transparent treatment.

## Editorial states

- `keep` — strong enough to retain and consider for canonical promotion.
- `provisional` — useful in prototypes but requires focused biological QA before promotion.
- `remake` — retain for audit/history only; do not promote.

Quality scores are editorial production metadata, not user-facing rarity, taxonomy confidence or product scoring.
